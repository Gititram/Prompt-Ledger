#!/usr/bin/env node
import { report, request } from '@prompt-ledger/sdk';

function parseArgs(){
  const [, , cmd, ...rest] = process.argv;
  const args = {};
  for (let i=0;i<rest.length;i++){
    if (rest[i].startsWith('--')) {
      const k = rest[i].slice(2);
      const v = (i+1<rest.length && !rest[i+1].startsWith('--')) ? rest[++i] : true;
      args[k]=v;
    }
  }
  return { cmd, args };
}

function toCSV(rows){
  const esc = v => `"${String(v??'').replace(/"/g,'""')}"`;
  const head = ["timestamp_iso","key","project","source","input_tokens","output_tokens","prompt_len","answer_len"];
  const lines = [head.join(",")];
  for (const r of rows) {
    lines.push([
      new Date(r.ts).toISOString(),
      r.key, r.projectId ?? "", r.source ?? "",
      r.inputTokens ?? 0, r.outputTokens ?? 0,
      (r.prompt?.length ?? 0), (r.answer?.length ?? 0)
    ].map(esc).join(","));
  }
  return lines.join("\n");
}

async function main(){
  const { cmd, args } = parseArgs();
  if (cmd === 'report' || cmd === 'export') {
    const r = await report({ by:'day' });
    const rows = r.records;
    const format = args.format || (cmd==='export'?'csv':'table');
    if (format === 'json') {
      console.log(JSON.stringify({ totals: r.totals, records: rows }, null, 2));
    } else if (format === 'csv') {
      console.log(toCSV(rows));
    } else {
      console.log(`Totals: requests=${r.totals.requests} input=${r.totals.input} output=${r.totals.output}`);
      console.log('Last 5:');
      for (const row of rows.slice(-5)) {
        console.log(`- ${row.source} ${row.key} in=${row.inputTokens} out=${row.outputTokens}`);
      }
    }
  } else if (cmd === 'demo') {
    const res1 = await request('hello ledger', async()=> 'Echo: hello ledger', { projectId:'demo' });
    const res2 = await request('hello ledger', undefined, { projectId:'demo' });
    console.log(res1.source, res2.source);
  } else {
    console.log('Usage: pl report [--format table|json|csv] | pl export --format csv | pl demo');
  }
}

main().catch(e=>{ console.error(e); process.exit(1); });