import { promises as fs } from 'fs';
import { dirname, join } from 'path';
import { fileURLToPath } from 'url';

const isBrowser = typeof window !== 'undefined' && typeof document !== 'undefined';

const HOME = process.env.HOME || process.cwd();
const DIR = process.env.PROMPT_LEDGER_DIR || (HOME + '/.prompt-ledger');
const FILE = DIR + '/pl.json';

async function ensureFile(){ try{ await fs.mkdir(DIR, { recursive: true }); }catch{} try{ await fs.access(FILE); }catch{ await fs.writeFile(FILE, '{}', 'utf8'); } }

async function loadNode(): Promise<Record<string, any>>{
  await ensureFile();
  try { const txt = await fs.readFile(FILE, 'utf8'); return JSON.parse(txt||'{}'); } catch { return {}; }
}
async function saveNode(db: Record<string, any>){ await ensureFile(); await fs.writeFile(FILE, JSON.stringify(db,null,2), 'utf8'); }

function loadBrowser(): Record<string, any>{
  try{ return JSON.parse(localStorage.getItem('prompt-ledger') || '{}'); }catch{ return {}; }
}
function saveBrowser(db: Record<string, any>){
  try{ localStorage.setItem('prompt-ledger', JSON.stringify(db)); }catch{}
}

export const cache = {
  async get(key: string){
    const db = isBrowser ? loadBrowser() : await loadNode();
    return db[key] || null;
  },
  async put(key: string, rec: any){
    const db = isBrowser ? loadBrowser() : await loadNode();
    db[key] = rec;
    if (isBrowser) saveBrowser(db); else await saveNode(db);
  },
  async clear(){
    if (isBrowser) saveBrowser({}); else await saveNode({});
  },
  async all(): Promise<Record<string, any>>{
    return isBrowser ? loadBrowser() : await loadNode();
  }
};