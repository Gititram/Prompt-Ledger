export function makeKey(s: string){
  const n=(s??'').toLowerCase().replace(/\s+/g,' ').trim();
  let h=2166136261>>>0;
  for (let i=0;i<n.length;i++){ h ^= n.charCodeAt(i); h += (h<<1)+(h<<4)+(h<<7)+(h<<8)+(h<<24); }
  return ('00000000'+(h>>>0).toString(16)).slice(-8);
}