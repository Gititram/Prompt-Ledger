let enc: any | null = null;

export async function initTokenizer(){
  if (enc) return enc;
  try {
    // dynamic import to avoid bundler issues
    const mod = await import('gpt-tokenizer');
    enc = mod;
  } catch {
    enc = null;
  }
  return enc;
}

export async function estimateTokens(text: string): Promise<number> {
  if (!text) return 0;
  try {
    if (!enc) await initTokenizer();
    if (enc && enc.encode) return (enc.encode(String(text)) as number[]).length;
  } catch {}
  return Math.max(0, ((text ?? '').length/4) | 0);
}