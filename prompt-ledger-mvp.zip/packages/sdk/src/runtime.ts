import { cache } from './store.js';
import { makeKey } from './makeKey.js';
import { estimateTokens } from './tokenizer.js';
import type { RequestCtx, RecordEntry } from './index.js';

export async function request(prompt: string, fetcher?: () => Promise<string>, ctx?: RequestCtx): Promise<RecordEntry>{
  const key = makeKey(prompt);
  const hit = await cache.get(key);
  if (hit) return { ...hit, source: 'cache' };
  if (!fetcher) throw new Error('Not in cache and no fetcher provided');
  const answer = await fetcher();
  const rec: RecordEntry = {
    key, prompt, answer,
    inputTokens: await estimateTokens(prompt),
    outputTokens: await estimateTokens(answer),
    ts: Date.now(), source: 'live', channel: ctx?.channel, projectId: ctx?.projectId
  };
  await cache.put(key, rec);
  return rec;
}

export async function allRecords(): Promise<RecordEntry[]>{
  const db = await cache.all();
  return Object.values(db) as RecordEntry[];
}

export async function report(_opts?: {by?: 'day'|'project'}){
  const rows = await allRecords();
  const totals = {
    input: rows.reduce((a,r)=>a+(r.inputTokens||0),0),
    output: rows.reduce((a,r)=>a+(r.outputTokens||0),0),
    requests: rows.length,
    savedViaCache: 0
  };
  return { totals, records: rows };
}