export type RequestCtx = { projectId?: string; channel?: string; meta?: Record<string,any> };
export type RecordEntry = {
  key: string; prompt: string; answer: string;
  inputTokens: number; outputTokens: number;
  ts: number; source: 'live'|'cache'; channel?: string; projectId?: string;
};

export { makeKey } from './makeKey.js';
export { estimateTokens } from './tokenizer.js';
export { cache } from './store.js';
export { request, report, allRecords } from './runtime.js';