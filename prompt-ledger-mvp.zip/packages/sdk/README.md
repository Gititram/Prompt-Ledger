# @prompt-ledger/sdk (MVP)
```bash
pnpm i
pnpm -C packages/sdk build
```
Usage:
```ts
import { request } from '@prompt-ledger/sdk';
const res = await request('design a links table', async ()=>'Echo: design a links table', { projectId:'demo' });
console.log(res.source, res.inputTokens, res.outputTokens);
```