# Prompt Ledger (SDK + CLI — Minimal MVP)

Local-first cache + token accounting for AI prompts/responses.

## Packages
- `@prompt-ledger/sdk` — TypeScript SDK (Node + Browser, local JSON/LocalStorage).
- `@prompt-ledger/cli` — Node CLI (`pl`) for reports/exports using the SDK store.

## Quickstart (Local Dev)
```bash
pnpm i
pnpm -w build
# demo
node examples/demo.mjs
```

## Publish (optional)
- Publish `packages/sdk` to npm as `@prompt-ledger/sdk`
- Publish `packages/cli` to npm as `@prompt-ledger/cli`

## CLI (once built locally)
```bash
node packages/cli/dist/index.js report --format table
node packages/cli/dist/index.js export --format csv > report.csv
```