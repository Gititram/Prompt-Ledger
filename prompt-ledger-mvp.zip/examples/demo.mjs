import { request, report } from "../packages/sdk/dist/index.js";
const live = async p => `Echo: ${p}`;
await request('design a links table for supabase', () => live('design a links table for supabase'), { projectId:'demo' });
await request('design a links table for supabase', undefined, { projectId:'demo' });
console.log(await report());